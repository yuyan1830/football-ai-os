import os
import json
from datetime import datetime


# ��Ŀ��Ŀ¼
ROOT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        ".."
    )
)


# ��ʼ������
REPORT = {
    "created": [],
    "skipped": [],
    "failed": [],
    "time": ""
}


# ��Ҫ������Ŀ¼
DIRECTORIES = [

    "00_System_OS/01_DATA_LAYER/core",

    "00_System_OS/01_DATA_LAYER/core",

    "00_System_OS/01_DATA_LAYER/core/logger",

    "00_System_OS/01_DATA_LAYER/core/exception",

    "00_System_OS/01_DATA_LAYER/core/validator",

    "00_System_OS/01_DATA_LAYER/core/database",

    "00_System_OS/01_DATA_LAYER/core/file_service",

    "00_System_OS/01_DATA_LAYER/core/config_loader",

    "00_System_OS/01_DATA_LAYER/core/datetime_service",

    "00_System_OS/01_DATA_LAYER/core/hash_service",

    "97_TESTS/core",

    "99_DOCUMENTATION/reports"

]


# ��Ҫ�����ĳ�ʼ���ļ�
FILES = {

"00_System_OS/01_DATA_LAYER/core/__init__.py":
"# Common Services Package\n",

"00_System_OS/01_DATA_LAYER/core/logger/__init__.py":
"# Logger Service\n",

"00_System_OS/01_DATA_LAYER/core/exception/__init__.py":
"# Exception Service\n",

"00_System_OS/01_DATA_LAYER/core/validator/__init__.py":
"# Validator Service\n"

}



def create_directory(path):

    full_path = os.path.join(
        ROOT,
        path
    )


    if os.path.exists(full_path):

        print(
            "[����Ŀ¼]",
            path
        )

        REPORT["skipped"].append(path)

        return


    os.makedirs(full_path)

    print(
        "[����Ŀ¼]",
        path
    )

    REPORT["created"].append(path)



def create_file(path, content):

    full_path = os.path.join(
        ROOT,
        path
    )


    if os.path.exists(full_path):

        print(
            "[�����ļ�]",
            path
        )

        REPORT["skipped"].append(path)

        return


    with open(
        full_path,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(content)


    print(
        "[�����ļ�]",
        path
    )

    REPORT["created"].append(path)



def save_report():

    REPORT["time"] = datetime.now().isoformat()


    report_path = os.path.join(
        ROOT,
        "99_DOCUMENTATION",
        "reports",
        "framework_init_report.json"
    )


    with open(
        report_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            REPORT,
            f,
            indent=4,
            ensure_ascii=False
        )



def main():

    print("====================")
    print("Football AI OS Initializer")
    print("====================")


    for d in DIRECTORIES:

        create_directory(d)


    for file,content in FILES.items():

        create_file(
            file,
            content
        )


    save_report()


    print("====================")
    print("���")
    print(REPORT)
    print("====================")



if __name__ == "__main__":

    main()
