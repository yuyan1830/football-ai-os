import json
import os
import shutil
from datetime import datetime


REGISTRY_PATH = (
    r"E:\football_v\00_System_OS\File_Manager"
    r"\registry\file_registry_v11.json"
)


ARCHIVE_ROOT = (
    r"E:\football_v\01_Data_Archive"
)


REPORT_PATH = (
    r"E:\football_v\00_System_OS\File_Manager"
    r"\archive\archive_report.json"
)



def load_json(path):

    if not os.path.exists(path):
        return []

    with open(
        path,
        "r",
        encoding="utf-8"
    ) as f:

        return json.load(f)



def save_json(path,data):

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            data,
            f,
            indent=4
        )



def get_target_folder(status):

    mapping = {

        "ACTIVE":
            "active",

        "ARCHIVED":
            "history",

        "DEPRECATED":
            "deprecated",

        "DELETE_PENDING":
            "delete_pending"

    }

    return mapping.get(
        status,
        "history"
    )



def run():


    assets = load_json(
        REGISTRY_PATH
    )


    report=[]


    for asset in assets:


        status = asset.get(
            "Lifecycle_Status"
        )


        folder = get_target_folder(
            status
        )


        target = os.path.join(
            ARCHIVE_ROOT,
            folder
        )


        if not os.path.exists(target):

            os.makedirs(target)


        report.append({

            "Asset_ID":
            asset.get("Asset_ID"),

            "Status":
            status,

            "Archive_Path":
            target,

            "Time":
            datetime.now().isoformat()

        })


    save_json(
        REPORT_PATH,
        report
    )


    print(
        "Archive Manager V1.1 completed:",
        len(report),
        "assets"
    )



if __name__=="__main__":

    print(
        "Football AI OS Archive Manager V1.1"
    )

    run()