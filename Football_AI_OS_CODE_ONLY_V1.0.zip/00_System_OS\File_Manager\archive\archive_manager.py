import os
import json
import shutil
from datetime import datetime


SOURCE_ROOT = r"E:\football_v"

ARCHIVE_ROOT = (
    r"E:\football_v\00_System_OS\File_Manager"
    r"\archive\storage"
)

INDEX_PATH = (
    r"E:\football_v\00_System_OS\File_Manager"
    r"\archive\archive_index.json"
)


def load_index():

    if os.path.exists(INDEX_PATH):

        with open(
            INDEX_PATH,
            "r",
            encoding="utf-8"
        ) as f:

            return json.load(f)

    return []



def save_index(data):

    with open(
        INDEX_PATH,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            data,
            f,
            indent=4
        )



def create_archive_record(
        file_path,
        reason
):


    archive_time = datetime.now()


    file_name = os.path.basename(
        file_path
    )


    archive_folder = os.path.join(
        ARCHIVE_ROOT,
        archive_time.strftime("%Y%m%d_%H%M%S")
    )


    os.makedirs(
        archive_folder,
        exist_ok=True
    )


    archive_path = os.path.join(
        archive_folder,
        file_name
    )


    shutil.copy2(
        file_path,
        archive_path
    )


    record = {


        "Original_Path":
            file_path,


        "Archive_Path":
            archive_path,


        "Archive_Time":
            archive_time.isoformat(),


        "Reason":
            reason,


        "Status":
            "ARCHIVED"

    }


    return record



def archive_test_file():

    index = load_index()


    test_files = []


    for root, dirs, files in os.walk(
        SOURCE_ROOT
    ):

        for file in files:

            if file.endswith(
                ".csv"
            ):

                test_files.append(
                    os.path.join(
                        root,
                        file
                    )
                )


    for file_path in test_files[:3]:


        record = create_archive_record(
            file_path,
            "Archive_Test"
        )


        index.append(
            record
        )


    save_index(
        index
    )


    print(
        "Archive completed:",
        len(test_files[:3]),
        "files"
    )



if __name__ == "__main__":


    print(
        "Football AI OS Archive Manager V1.0"
    )


    archive_test_file()